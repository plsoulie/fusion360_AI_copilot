
import { Chat } from "@/components/Chat";

const Index = () => {
  return (
    <div className="h-screen w-full flex flex-col">
      <div className="border-b p-4 bg-white">
        <h1 className="text-xl font-semibold text-gray-900">Fusion 360 Assistant</h1>
        <p className="text-sm text-gray-600 mt-1">
          Get help with modeling, documentation, and general Fusion 360 questions. Your CAD companion is here to assist you.
        </p>
      </div>
      <div className="flex-1">
        <Chat />
      </div>
    </div>
  );
};

export default Index;
